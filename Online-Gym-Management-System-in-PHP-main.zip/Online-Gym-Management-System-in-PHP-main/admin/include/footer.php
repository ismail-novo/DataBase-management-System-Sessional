<footer class="">
		<div class="container">
			
			<div class="footer-bottom">
				<div class="row">
					
					<div class="col-md-8 text-md-right">
						<div class="copyright"> 
GYM Managaement System - Code Camp BD <?php echo date('Y') ?></div>
					</div>
				</div>
			</div>
		</div>
	</footer>

		<!-- 


	- Author Name: MH RONY.
	- GigHub Link: https://github.com/dev-mhrony
	- Facebook Link:https://www.facebook.com/dev.mhrony
	- Youtube Link: <a href = "https://www.youtube.com/@codecampbdofficial"> Code Camp BD</a>
	- for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com
	- Visit My Website : https://dev-mhrony.com
	 -->